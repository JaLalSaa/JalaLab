# 🧪 Project: Profile Card

**Goal:** Practice basic HTML structure and CSS styling by building a simple anime-styled profile card.

## 🔧 What I Learned:
- HTML structure (div, img, h1, p, a)
- Basic CSS styling (colors, fonts, layout)
- Avatar circles, shadows, and layout centering

## 📸 Preview:
Coming soon (add screenshot if needed)
